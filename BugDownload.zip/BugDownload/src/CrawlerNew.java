import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

public class CrawlerNew {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<1;i++) {
			String addr="https://github.com/search?p="+i+"&q=java&type=Repositories";
			String text=getContent(addr);
			List<String> repoNames=getRepositories(text);
			for(String name : repoNames) {
				System.out.println(name);
				String url="https://github.com"+name+".git";
				addr="https://api.github.com/repos"+name+"/commits";
				//System.out.println(addr);
				text=getContent(addr);
				List<String> commits=getCommits(text);
				for(String commit : commits) {
					//System.out.println(url+"   "+commit);
				}
				break;
			}
		}
		
		
	}
	
	public static String getContent(String addr) {
		String text="";
		try {
			URL url = new URL(addr);
            URLConnection URLconnection = url.openConnection();

            HttpURLConnection httpConnection = (HttpURLConnection) URLconnection;
            
            httpConnection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
            //httpConnection.setRequestProperty("Accept-Encoding", "gzip, deflate, br");
            httpConnection.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
            httpConnection.setRequestProperty("Connection", "keep-alive");
            httpConnection.setRequestProperty("Cookie", "_ga=GA1.2.753922983.1523346515; _octo=GH1.1.1859834358.1523346515; _device_id=9824d7ddc1e763bf637ada72789fd4eb; tz=Asia%2FShanghai; user_session=1IYULihVcpyd5YjBwICF7e4NC2jiAAyZ4dlM3NUpGCHzM8pV; __Host-user_session_same_site=1IYULihVcpyd5YjBwICF7e4NC2jiAAyZ4dlM3NUpGCHzM8pV; logged_in=yes; dotcom_user=TyrantJin; has_recent_activity=1; _gat=1; _gh_sess=TVN6VDh1TGMrbkg4bkJ3WkFtcDVxOHZsb0J2bjkrVHFKUGQxTlBJRzRlR2VYbGpiaVVzQmF2TFBNYXFLeUxSS2xTbk9FdWJsQVVHblJ6b3YyUnhmbXRsWmRqYk5uOVAxVnVBWGc2WCtDWk4xUk9Zc3JCMXhUcEUydVNIdkRGdWx4N1lwT3dlK2VGRXkyRHcxcWhWOUl5Tk1QRmt6Sy9UTktWbFFlUnRkMFVWekpWSzRQWml0RW52S251NEQ1R3BiVElRcERsajFkYTVwNEVldERXL3BJajJGczdKNkg2emcyUUNROWRCY1NIT3ZkY3daT1BqSUwyL1FoSnpzTWY2QkR1dkpkM3dVdlVwRVFnUDBRQ1AzeGJTTTlvc0dTUVR1QnVuY2FXZHAxZFUvUkt4Y2FpUUs5bzY3blBiSG9jOFF3WWViTzlPcXhCRUxLaFBGeGVoVG13PT0tLS9tL1JWNU5HSzBjWmlGUFNSVWZabEE9PQ%3D%3D--6423f4eb43310463d3bca3bc863daf7ffbdc0c21");
            httpConnection.setRequestProperty("Upgrade-Insecure-Requests", "1");
            httpConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36");
            int responseCode = httpConnection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {  
                InputStream in = httpConnection.getInputStream();
                InputStreamReader isr = new InputStreamReader(in);
                BufferedReader bufr = new BufferedReader(isr);
                String str;
                while ((str = bufr.readLine()) != null) {
                    //System.out.println(str);
                	text+=str;
                }
                
                
            } else {
                System.err.println("Error");
            }
		}catch(Exception e) {
			e.printStackTrace();
		}
		return text;
	}
	
	public static List<String> getRepositories(String text) {
		List<String> names=new ArrayList<String>();
		Document doc=Jsoup.parse(text);
		Elements es=doc.select("a.v-align-middle");
		for(Element e : es) {
			String repoName=e.attr("href");
			//System.out.println(url);
			names.add(repoName);
		}
		return names;
	}
	
	public static List<String> getCommits(String text) {
		List<String> ids=new ArrayList<String>();
		JsonParser parser = new JsonParser();
	    JsonArray array = parser.parse(text).getAsJsonArray();
	    for(int i=0;i<array.size();i++) {
	    	String id=array.get(i).getAsJsonObject().get("sha").getAsString();
	    	ids.add(id);
	    }
		return ids;
	}

}
