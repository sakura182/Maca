import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ExtractInfo {

	//static String path="D:\\TestCase\\txt\\";
	static String path="J:\\code_generation\\test_case\\new_bugreport\\BugDownload\\txt2";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
	        Connection conn = DriverManager.getConnection(
	                "jdbc:mysql://127.0.0.1:3306/test?serverTimezone=GMT&characterEncoding=utf8",
	                "root","root");
        	
	        PreparedStatement ps=conn.prepareStatement("select * from BugReports");
	        ResultSet rs=ps.executeQuery();
	        int index=0;
	        int ok=0;
	        while(rs.next()) {
	        	String id=rs.getString(1);
	        	//System.out.println("------------------------"+id);
	        	String html=rs.getString(4);
	        	//System.out.println(html);
	        	Document doc=Jsoup.parse(html);
	        	Elements es=doc.getAllElements();
	        	//Element pre=es.first();
	        	String text="";
	        	boolean flag=false;
	        	for(int i=0;i<es.size();i++) {
	        		Element e=es.get(i);
	        		if(e.tagName().equals("h2")||e.tagName().equals("h3")) {
	        			if(isRepro(e.text())) {
	        				flag=true;
	        				continue;
	        			}
	        			else
	        				flag=false;
	        		}
	        		if(e.tagName().equals("hr")) flag=false;
	        		if(flag) {
	        			if(e.tagName().equals("p"))
	        				//System.out.println(e.text());
	        				text+=e.text()+"\r\n";
	        			else if(e.parent().tagName().equals("p"))
	        				continue;
	        			else if(!e.ownText().equals(""))
	        				//System.out.println(e.ownText());
	        				text+=e.ownText()+"\r\n";
	        		}
	        	}
	        	if(!text.equals("")) {
	        		generateTXT(text,""+index+"#####"+id+".txt");
	        		//System.out.println("Done");
	        		ok++;
	        	}
	        	index++;
	        	//if(index>=10) break;
	        	System.out.println(ok+"    "+index);
	        }
	        ps.close();
	        conn.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean isRepro(String text) {
		text=text.toLowerCase();
		if(Pattern.matches(".*steps to reproduce.*",text))
			return true;
		if(Pattern.matches(".*reproduction.*",text))
			return true;
		return false;
	}
	
	public static void generateTXT(String text,String name) throws IOException {
		File f=new File(path+name);
		if(f.exists()) f.delete();
		if(f.createNewFile()) {
			FileWriter writer = new FileWriter(f);
			BufferedWriter out = new BufferedWriter(writer);
			out.write(text);
			out.flush();
			out.close();
			writer.close();
		}
	}
	
}
