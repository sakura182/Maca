import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.sql.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Crawler {

	static int MAXPAGE=200;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Class.forName("com.mysql.jdbc.Driver");
	        Connection conn = DriverManager.getConnection(
	                "jdbc:mysql://127.0.0.1:3306/test?serverTimezone=GMT&characterEncoding=utf8",
	                "root","root");
        	
	        PreparedStatement ps=conn.prepareStatement("insert into BugReports values(?,?,?,?)");
	        int total=0;
			for(int i=1;i<=MAXPAGE;i++) {
				ArrayList<BugReport> bps=getList(i);
				for(BugReport bp : bps) {
					String text=getContent(bp.url);
					ps.setString(1, bp.id);
					ps.setString(2, bp.title);
					ps.setString(3, bp.url);
					ps.setString(4, text);
					ps.execute();
					total++;
					Thread.sleep(3000);
				}
				System.out.println("Page "+i+" Done    Total: "+total);
			}

			ps.close();
			conn.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	public static ArrayList<BugReport> getList(int pagenum) {
		ArrayList<BugReport> bps=new ArrayList<BugReport>();
		try {
			URL url = new URL("https://github.com/search?p="+pagenum+"&q=android+reproduce&type=Issues");
            URLConnection URLconnection = url.openConnection();
            //q=android+reproduce&type=Issues

            HttpURLConnection httpConnection = (HttpURLConnection) URLconnection;
            
            httpConnection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
            //httpConnection.setRequestProperty("Accept-Encoding", "gzip, deflate, br");
            httpConnection.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
            httpConnection.setRequestProperty("Connection", "keep-alive");
            httpConnection.setRequestProperty("Cookie", "_ga=GA1.2.753922983.1523346515; _octo=GH1.1.1859834358.1523346515; _device_id=9824d7ddc1e763bf637ada72789fd4eb; tz=Asia%2FShanghai; user_session=1IYULihVcpyd5YjBwICF7e4NC2jiAAyZ4dlM3NUpGCHzM8pV; __Host-user_session_same_site=1IYULihVcpyd5YjBwICF7e4NC2jiAAyZ4dlM3NUpGCHzM8pV; logged_in=yes; dotcom_user=TyrantJin; has_recent_activity=1; _gat=1; _gh_sess=TVN6VDh1TGMrbkg4bkJ3WkFtcDVxOHZsb0J2bjkrVHFKUGQxTlBJRzRlR2VYbGpiaVVzQmF2TFBNYXFLeUxSS2xTbk9FdWJsQVVHblJ6b3YyUnhmbXRsWmRqYk5uOVAxVnVBWGc2WCtDWk4xUk9Zc3JCMXhUcEUydVNIdkRGdWx4N1lwT3dlK2VGRXkyRHcxcWhWOUl5Tk1QRmt6Sy9UTktWbFFlUnRkMFVWekpWSzRQWml0RW52S251NEQ1R3BiVElRcERsajFkYTVwNEVldERXL3BJajJGczdKNkg2emcyUUNROWRCY1NIT3ZkY3daT1BqSUwyL1FoSnpzTWY2QkR1dkpkM3dVdlVwRVFnUDBRQ1AzeGJTTTlvc0dTUVR1QnVuY2FXZHAxZFUvUkt4Y2FpUUs5bzY3blBiSG9jOFF3WWViTzlPcXhCRUxLaFBGeGVoVG13PT0tLS9tL1JWNU5HSzBjWmlGUFNSVWZabEE9PQ%3D%3D--6423f4eb43310463d3bca3bc863daf7ffbdc0c21");
            httpConnection.setRequestProperty("Upgrade-Insecure-Requests", "1");
            httpConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36");
            int responseCode = httpConnection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {  
                InputStream in = httpConnection.getInputStream();
                InputStreamReader isr = new InputStreamReader(in);
                BufferedReader bufr = new BufferedReader(isr);
                String str,text="";
                while ((str = bufr.readLine()) != null) {
                    //System.out.println(str);
                	text+=str;
                }
                
                Document doc=Jsoup.parse(text);
    			Elements es=doc.select("div.flex-auto").select(".min-width-0").select(".public");
    			for(Element e : es) {
    				//System.out.println(e.html());
    				String id=e.select("span.text-gray").text();
    				//System.out.println(id);
    				String title=e.select("a").get(0).attr("title");
    				//System.out.println(title);
    				String temp=e.select("a").get(0).attr("data-hydro-click");
    				//"url":"https://github.com/sqlcipher/android-database-sqlcipher/issues/462"
    				int pos=temp.indexOf("\"url\":\"");
    				temp=temp.substring(pos+7,temp.length());
    				pos=temp.indexOf("\"");
    				String url1=temp.substring(0,pos);
    				//System.out.println(url1);
    				
    				bps.add(new BugReport(id,title,url1));
    			}
            } else {
                System.err.println("Page : "+pagenum+"  Fail!!!");
            }
		}catch(Exception e) {
			e.printStackTrace();
		}
		return bps;
	}

	public static String getContent(String address) {
		try {
			URL url = new URL(address);
            URLConnection URLconnection = url.openConnection();

            HttpURLConnection httpConnection = (HttpURLConnection) URLconnection;
            
            httpConnection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
            //httpConnection.setRequestProperty("Accept-Encoding", "gzip, deflate, br");
            httpConnection.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
            httpConnection.setRequestProperty("Connection", "keep-alive");
            httpConnection.setRequestProperty("Cookie", "_ga=GA1.2.753922983.1523346515; _octo=GH1.1.1859834358.1523346515; _device_id=9824d7ddc1e763bf637ada72789fd4eb; tz=Asia%2FShanghai; user_session=1IYULihVcpyd5YjBwICF7e4NC2jiAAyZ4dlM3NUpGCHzM8pV; __Host-user_session_same_site=1IYULihVcpyd5YjBwICF7e4NC2jiAAyZ4dlM3NUpGCHzM8pV; logged_in=yes; dotcom_user=TyrantJin; has_recent_activity=1; _gat=1; _gh_sess=TVN6VDh1TGMrbkg4bkJ3WkFtcDVxOHZsb0J2bjkrVHFKUGQxTlBJRzRlR2VYbGpiaVVzQmF2TFBNYXFLeUxSS2xTbk9FdWJsQVVHblJ6b3YyUnhmbXRsWmRqYk5uOVAxVnVBWGc2WCtDWk4xUk9Zc3JCMXhUcEUydVNIdkRGdWx4N1lwT3dlK2VGRXkyRHcxcWhWOUl5Tk1QRmt6Sy9UTktWbFFlUnRkMFVWekpWSzRQWml0RW52S251NEQ1R3BiVElRcERsajFkYTVwNEVldERXL3BJajJGczdKNkg2emcyUUNROWRCY1NIT3ZkY3daT1BqSUwyL1FoSnpzTWY2QkR1dkpkM3dVdlVwRVFnUDBRQ1AzeGJTTTlvc0dTUVR1QnVuY2FXZHAxZFUvUkt4Y2FpUUs5bzY3blBiSG9jOFF3WWViTzlPcXhCRUxLaFBGeGVoVG13PT0tLS9tL1JWNU5HSzBjWmlGUFNSVWZabEE9PQ%3D%3D--6423f4eb43310463d3bca3bc863daf7ffbdc0c21");
            httpConnection.setRequestProperty("Upgrade-Insecure-Requests", "1");
            httpConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36");
            int responseCode = httpConnection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {  
                InputStream in = httpConnection.getInputStream();
                InputStreamReader isr = new InputStreamReader(in);
                BufferedReader bufr = new BufferedReader(isr);
                String str,text="";
                while ((str = bufr.readLine()) != null) {
                    //System.out.println(str);
                	text+=str;
                }
                Document doc=Jsoup.parse(text);
                Elements es=doc.select("td.d-block").select(".comment-body");//.select("markdown-body");//.select("js-comment-body");
                return es.get(0).html();
            }
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	
}
