
public class BugReport {
	public String id,title,url,text;
	
	public BugReport(String id,String title,String url) {
		this.id=id;
		this.title=title;
		this.url=url;
	}
	
}
